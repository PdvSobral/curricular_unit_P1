/* Encoding: UTF-8
@Authors: Pedro Sobral (33641)
@Date: 03/06/2025
*/
#define __main__	// because of it is the first, the other will not compile if not this line

#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <ctype.h>
#include <stdint.h>
#include <termios.h>    // -> Disabl_ctrl_d (IN) functions.c
#include <signal.h>		// -> To remap CTRL+C
#include <string.h>		// strcmp, strlens
#include <unistd.h>		// sleep, STDIN_FILENO

#ifndef psystem
	#pragma GCC warning "Loaded standard modules. Please use strlen2 instead of strlen."
#else
	#include "good_practices.c"
	// Basicly imports the four modules above
	// Makes so that int, unsigned and other lables/macros are not usable
	#pragma GCC warning "Loaded custom module."
#endif

#include "functions.c"
#include "linked_lists.c"

#define MAX_NAME_LENGTH 50

typedef struct _account{
	char name[MAX_NAME_LENGTH+2];
	LinkedList* connections;
} ACCOUNT;

// Defenition of the menu arrays
const uint8_t len_main_menu = 9;
const char main_menu[][CABECALHO_LEN] = {
	"Add user✅",					// 1
	"Select user✅",					// 2
	"Add connection✅",				// 3
	"Remove connection",			// 4
	"Remove user",					// 5
	"How many current users?✅",		// 6
	"Currently selected?✅",			// 7
	"Unselect current user!✅",		// 8
	"Exit✅"							// 0
};

// GLOBAL VARIABLES TODO: To remove global and pass a context.
LinkedList* SYSTEM;
NODE* CURRENTLY_SELECTED = NULL;

// FUNCTIONS

int64_t menu_students(const char tittle[], uint8_t len_cabecalho, LinkedList* to_use){
	/*
	Função para apresentar ao utilizador um menu
	Argumentos:
		char tittle[]							 -> Tittle for the menu
		const char menu_options[][CABECALHO_LEN] -> Array de strings a usar como opções do menu
		uint8_t menu_size                        -> Número de opções a ler do array passado
		uint8_t last_zero                        -> Torna a uĺtima opção sempre zero, independentemente das outras
	Retorno:
		int64_t -> Escolha do utilizador
	*/
	uint8_t wrong=0;
	int64_t _option;
	uint8_t numeric_flag = 0;
	//For compatibility and less code changed
	uint8_t menu_size = to_use->size;
	menu_size++;
	uint8_t last_zero = 1;
	while(1){
		cabecalho(tittle, len_cabecalho);
		reset_line(len_cabecalho);
		char buffer[5];
		for(uint8_t _index=0; _index<(menu_size); _index++) {
			if(_index+last_zero == menu_size){
				printf("│  0 - Return to main menu");
				printf("\033[%uC│\n", CABECALHO_LEN - 27);
			} else {
				printf("│ %2d - %s", _index + 1, ((ACCOUNT*) get_node_at_index(to_use, _index)->data)->name);
				printf("\033[%uC│\n", CABECALHO_LEN - 8 - (uint8_t) strlen2(((ACCOUNT*) get_node_at_index(to_use, _index)->data)->name));
			}
		};
		printf("├");
		for(uint8_t _index = 0; _index<len_cabecalho-2; _index++){
			printf("─");
		} printf("┤\n");
		printf("\n└");
		for(uint8_t _index = 0; _index<len_cabecalho-2; _index++){
				printf("─");
			} printf("┘");
		printf("\033[1A\033[%dD", CABECALHO_LEN);
		printf("│ Introduza a sua opção: ");
		for (uint8_t i = 0; i < CABECALHO_LEN - 26; ++i) printf(" ");
		printf("│");

		if(wrong==1){
			printf("\n├\033[%uC┤", CABECALHO_LEN-2);
			printf("\n│ \033[31mInvalid Option!! Please enter a valid option.\033[m");
			printf("\033[%uC│\n└", CABECALHO_LEN - 48);
			for(uint8_t _index = 0; _index<len_cabecalho-2; _index++){
				printf("─");
			} printf("┘");
			printf("\033[3A\033[%dD\033[25C", CABECALHO_LEN);
		} else {
			printf("\033[%dD\033[25C", CABECALHO_LEN);
		}
		read_n_chars(3, buffer);
		_option = str_to_int64_t_flag(buffer, &numeric_flag);
		if((_option<=(menu_size-last_zero)) && ((1-last_zero) <= _option) && numeric_flag) break;
		wrong = 1;
		clear_screen();
	}
	printf("\n");
	return _option;
};

ACCOUNT* new_account(){
	ACCOUNT* _temp = (ACCOUNT*) malloc(sizeof(ACCOUNT));
	_temp->connections = create_linked_list();
	_temp->name[0] = 0x00;
	return _temp;
}

void add_user(){
	ACCOUNT* new_user = new_account();
	printf("Please enter your name: ");
	read_n_chars(MAX_NAME_LENGTH+1, new_user->name);
	if(strlen2(new_user->name) > MAX_NAME_LENGTH){
		free(new_user);
		printf("Too many characters entered!!");
		pause_();
		return;
	}
	append_data_to_list(SYSTEM, new_user);
	if (SYSTEM->size==0){
		printf("No users currently registered in the plataform, pls come back later to start having some fun!");
		return;
	}
	// TODO: Add connection, probably with menu... Like get all current users and just remove the one in the connections already.
}

void select_user(){
	if(SYSTEM->size==0){printf("No user register to select!\n"); pause_(); return;}
	// TODO: Add menu for user selection
	printf("IN DEBUG MODE, SELECTING FIRST USER\n");
	CURRENTLY_SELECTED=get_node_at_index(SYSTEM, 0);
	printf("Selected: '%s'\n", ((ACCOUNT*) CURRENTLY_SELECTED->data)->name);
	pause_();
	return;
}

void add_connection(){
	if(CURRENTLY_SELECTED==NULL) {printf("No user currently selected!\n"); pause_(); return;}
	// TODO: Make the selection for adding to the connections.
	printf("Selecting for: '%s'\n", ((ACCOUNT*) CURRENTLY_SELECTED->data)->name);
	//LinkedList* = ;
	uint8_t option = menu_students("NEW CONNECTION TO...", CABECALHO_LEN, SYSTEM);
	if(option==0) return;
	pause_();
	return;
}


int32_t main(void){
	/*
	Função primária do programa
	Argumentos:
		Nenhum
	Retorno:
		Nenhum
	*/
	SYSTEM = create_linked_list(); // C was complaining when in line
	signal(SIGINT, handle_sigint);
	disable_ctrl_d();
    fflush(stdin);
	uint8_t escolha_menu;

	while (1){
		clear_screen();
		escolha_menu = menu("MAIN MENU ", CABECALHO_LEN, main_menu, len_main_menu, 1);
		if(escolha_menu==0) break;
		switch(escolha_menu){
			case 1: add_user(); break;
			case 2: select_user(); break;
			case 3: add_connection(); break;
			case 6: printf("Currently registered: %d\n", SYSTEM->size); pause_(); break;
			case 7: printf("Currently selected: '%s'\n", (CURRENTLY_SELECTED!=NULL) ? ((ACCOUNT*) CURRENTLY_SELECTED->data)->name : "NULL"); pause_(); break;
			case 8: CURRENTLY_SELECTED=NULL; printf("Selected = NULL\n"); pause_(); break;
			default: printf("Function not implemented yet!!\n"); pause_();
		}
	}
	printf("Exiting...\n");
	enable_ctrl_d();
	return 0;
};









