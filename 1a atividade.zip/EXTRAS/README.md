# OBJETIVO
Pretende-se desenvolver um programa em C para modelar uma rede de amizades, com
relações de amizade diretas e indiretas entre pessoas.
Deverá:

a) Explicar as vantagens e desvantagens em modelar a rede de amizades com
recurso a um Grafo em comparação com outras estruturas de dados estudadas
anteriormente.

`Um Grafo permite a rápida análise de conecções entre vértices, e a única outra estrutura rival, LinkedLists, acabam por ser uma das formas possíveis para representar um grafo, tornando por isso um implementação com LinkedLists numa implementação de um grafo.`

b) Vértices e arestas são conceitos de Grafos. Qual a sua definição de como
poderiam ser utilizados para modelar a rede de amizades?

`Num grafo, um vértice é uma ligação entre vértices, e pode ter sentido ou não, dependendo do uso. Um vérice é o objeto ao qual se quer estudar as ligações. Neste caso seria um sistema de vértices = pessoas, arestas = follows.`

c) Descreva as seguintes implementações de grafos: matriz de adjacência e lista de
adjacência. Qual lhe parece mais adequada à resolução do exercício? Justifique.

`Um usa uma matriz para determinar ligações, sendo no entando um nadinha ineficiente. A outra forma usa uma lista ligada por vértice para indicar todas as suas conecções. Se uma conecção for presente nos dois vértices, então é uma ligação sem sentido ou de duplo sentido.
Provavelmente a maneira mais correta seria usando uma matriz, mas irei usar LinkedLists porque tenho um biblioteca já à espera de ser usada, e é facílimo obter o número de amizades a partir daí.`

d) Considerando a escolha efetuada na alínea anterior, implemente o projeto e
exemplifique com a inserção de pessoas e suas relações de amizade.
- i.  Adicionar pessoas e amizades

e) Implemente as seguintes funcionalidades:
- i.   Listar os amigos diretos de uma determinada pessoa;
- ii.  Verificar se duas pessoas estão ligadas por relações de amizade (direta ou
indiretamente);
- iii. Listar o grupo de amigos de uma determinada pessoa (com travessias);

Deverá ser submetido no moodle o código fonte da aplicação, bem como o relatório com
a resposta às questões colocadas.
