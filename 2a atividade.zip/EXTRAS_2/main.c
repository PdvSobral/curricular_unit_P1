/* Encoding: UTF-8
@Authors: Pedro Sobral (33641)
@Date: 03/06/2025
*/
#define __main__	// because of it is the first, the other will not compile if not this line

#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <ctype.h>
#include <stdint.h>
#include <termios.h>    // -> Disabl_ctrl_d (IN) functions.c
#include <signal.h>		// -> To remap CTRL+C
#include <string.h>		// strcmp, strlens
#include <unistd.h>		// sleep, STDIN_FILENO

#ifndef psystem
	#pragma GCC warning "Loaded standard modules. Please use strlen2 instead of strlen."
#else
	#include "good_practices.c"
	// Basicly imports the four modules above
	// Makes so that int, unsigned and other lables/macros are not usable
	#pragma GCC warning "Loaded custom module."
#endif

#include "functions.c"
#include "linked_lists.c"

#define MAX_NAME_LENGTH 50
#define MAX_CATEGORY 50

typedef struct _product{
	char name[MAX_NAME_LENGTH+2];
	char cat[MAX_CATEGORY+2];
	float price;
	uint16_t quantity;
} PRODUCT;
typedef struct _lol {
	LinkedList* maior;
	LinkedList* menor;
} LOL;

// Defenition of the menu arrays
const uint8_t len_main_menu = 7;
const char main_menu[][CABECALHO_LEN] = {
	"Add product to cart",								// 1
	"Remove product from cart",							// 2
	"List current products✅",							// 3
	"Total price to pay✅",								// 4
	"Get more expensive and least expensive items✅",	// 5
	"Summary by category",								// 6
	"Exit✅"												// 0
};

// GLOBAL VARIABLES TODO: To remove global and pass a context.
LinkedList* CART;

// FUNCTIONS
void nop(void* a){return;};

void print_product(PRODUCT* data){
	printf(
			"Name: %s\nCategory: %s\nQuantity %u\nPrice: %.2f\n",
			data->name,
			data->cat,
			data->quantity,
			data->price
	);
	return;
}
void add_product(){
	PRODUCT* _temp = malloc(sizeof(PRODUCT));
	// TODO: Check for same name and increase quantity, else add.
	strcpy(_temp->name, "Teste Name");
	strcpy(_temp->cat, "Teste Cat");
	_temp->quantity = 3;
	_temp->price = 1.99;
	print_product((PRODUCT*) ((NODE*) append_data_to_list(CART, _temp))->data);
	printf("Product added sucessfully!");
	pause_();
	return;
}
int64_t menu_products(const char tittle[], uint8_t len_cabecalho, LinkedList* to_use){
	/*
	Função para apresentar ao utilizador um menu
	Argumentos:
		char tittle[]							 -> Tittle for the menu
		const char menu_options[][CABECALHO_LEN] -> Array de strings a usar como opções do menu
		uint8_t menu_size                        -> Número de opções a ler do array passado
		uint8_t last_zero                        -> Torna a uĺtima opção sempre zero, independentemente das outras
	Retorno:
		int64_t -> Escolha do utilizador
	*/
	uint8_t wrong=0;
	int64_t _option;
	uint8_t numeric_flag = 0;
	//For compatibility and less code changed
	uint8_t menu_size = to_use->size;
	menu_size++;
	uint8_t last_zero = 1;
	while(1){
		cabecalho(tittle, len_cabecalho);
		reset_line(len_cabecalho);
		char buffer[5];
		for(uint8_t _index=0; _index<(menu_size); _index++) {
			if(_index+last_zero == menu_size){
				printf("│  0 - Return to main menu");
				printf("\033[%uC│\n", CABECALHO_LEN - 27);
			} else {
				printf("│ %2d - %s", _index + 1, ((PRODUCT*) get_node_at_index(to_use, _index)->data)->name);
				printf("\033[%uC│\n", CABECALHO_LEN - 8 - (uint8_t) strlen2(((PRODUCT*) get_node_at_index(to_use, _index)->data)->name));
			}
		};
		printf("├");
		for(uint8_t _index = 0; _index<len_cabecalho-2; _index++){
			printf("─");
		} printf("┤\n");
		printf("\n└");
		for(uint8_t _index = 0; _index<len_cabecalho-2; _index++){
				printf("─");
			} printf("┘");
		printf("\033[1A\033[%dD", CABECALHO_LEN);
		printf("│ Introduza a sua opção: ");
		for (uint8_t i = 0; i < CABECALHO_LEN - 26; ++i) printf(" ");
		printf("│");

		if(wrong==1){
			printf("\n├\033[%uC┤", CABECALHO_LEN-2);
			printf("\n│ \033[31mInvalid Option!! Please enter a valid option.\033[m");
			printf("\033[%uC│\n└", CABECALHO_LEN - 48);
			for(uint8_t _index = 0; _index<len_cabecalho-2; _index++){
				printf("─");
			} printf("┘");
			printf("\033[3A\033[%dD\033[25C", CABECALHO_LEN);
		} else {
			printf("\033[%dD\033[25C", CABECALHO_LEN);
		}
		read_n_chars(3, buffer);
		_option = str_to_int64_t_flag(buffer, &numeric_flag);
		if((_option<=(menu_size-last_zero)) && ((1-last_zero) <= _option) && numeric_flag) break;
		wrong = 1;
		clear_screen();
	}
	printf("\n");
	return _option;
};
void remove_product(){
	menu_products("TO REMOVE ", CABECALHO_LEN, CART);
	pause_();
	return;
}
void total_price_extra(void* a, void* b){
	float* to_pay = (float*) b;
	PRODUCT* to_check = (PRODUCT*) a;
	*to_pay += to_check->quantity * to_check->price;
	return;
}
void total_price(){
	// TODO: to make recursive as asked
	if(CART->size == 0){printf("No products added to the cart!\n"); pause_(); return;}
	float to_pay = 0;
	traverse_list2(CART, &to_pay, total_price_extra);
	printf("Total to pay: %.2f\n", to_pay);
	pause_();
	return;
}
void list_items(){
	if(CART->size == 0){printf("No products added to the cart!\n"); pause_(); return;}
	uint8_t menu_size = CART->size;
	cabecalho("PRODUCTS IN THE CART", CABECALHO_LEN);
	reset_line(CABECALHO_LEN);
	for(uint8_t _index=0; _index<(menu_size); _index++) {
		printf("│ %2d - (%3ux) %s", _index + 1, ((PRODUCT*) get_node_at_index(CART, _index)->data)->quantity, ((PRODUCT*) get_node_at_index(CART, _index)->data)->name);
		printf("\033[%uC│\n", CABECALHO_LEN - 15 - (uint8_t) strlen2(((PRODUCT*) get_node_at_index(CART, _index)->data)->name));
	}
	printf("└");
	for(uint8_t _index = 0; _index<CABECALHO_LEN-2; _index++){
			printf("─");
		} printf("┘");
	printf("\n");
	pause_();
	return;
}
void get_most_and_least_extra(void* a, void* b){
	// to make recursive as asked
	PRODUCT* prod = (PRODUCT*) a;
	LOL* lol = (LOL*) b;
	if(lol->maior->head == NULL){
		append_data_to_list(lol->maior, prod);
	} else if(prod->price > ((PRODUCT*) lol->maior->head->data)->price){
		delete_linked_list(lol->maior, nop);
		lol->maior = create_linked_list();
		append_data_to_list(lol->maior, prod);
	} else if(prod->price == ((PRODUCT*) lol->maior->head->data)->price){
		append_data_to_list(lol->maior, prod);
	}
	if(lol->menor->head == NULL){
		append_data_to_list(lol->menor, prod);
	} else if(prod->price < ((PRODUCT*) lol->menor->head->data)->price){
		delete_linked_list(lol->menor, nop);
		lol->menor = create_linked_list();
		append_data_to_list(lol->menor, prod);
	} else if(prod->price == ((PRODUCT*) lol->menor->head->data)->price){
		append_data_to_list(lol->menor, prod);
	}
	return;
}
void get_most_and_least(){
	// TODO: to make recursive as asked
	if(CART->size == 0){printf("No products added to the cart!\n"); pause_(); return;}
	// TODO: a resolver o segfault
	LOL* lol = malloc(sizeof(lol));
	lol->maior = create_linked_list();
	lol->menor = create_linked_list();
	traverse_list2(CART, lol, get_most_and_least_extra);
	printf("Biggest: %.2f\nLowest: %.2f\n", ((PRODUCT*) lol->maior->head->data)->price, ((PRODUCT*) lol->menor->head->data)->price);
	free(lol);
	pause_();
	return;
}

int32_t main(void){
	/*
	Função primária do programa
	Argumentos:
		Nenhum
	Retorno:
		Nenhum
	*/
	CART = create_linked_list(); // C was complaining when in line
	signal(SIGINT, handle_sigint);
	disable_ctrl_d();
    fflush(stdin);
	uint8_t escolha_menu;

	while (1){
		clear_screen();
		escolha_menu = menu("MAIN MENU ", CABECALHO_LEN, main_menu, len_main_menu, 1);
		if(escolha_menu==0) break;
		switch(escolha_menu){
			case 1: add_product(); break;
			case 2: remove_product(); break;
			case 3: list_items(); break;
			case 4: total_price(); break;
			case 5: get_most_and_least(); break;
			default: printf("Function not implemented yet!!\n"); pause_();
		}
	}
	printf("Exiting...\n");
	enable_ctrl_d();
	return 0;
};









