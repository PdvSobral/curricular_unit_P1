# OBJETIVO
Pretende-se desenvolver um programa em C implementar numa lista ligada um carrinho
de compras.

### Artigo
Cada nó da lista deve ter um artigo com os seguintes dados:
 - nome
 - quantidade
 - preço unitário
 - categoria

## Implementa as seguintes operações:
- a) Inserir artigos no carrinho de compras;
- b) Listar os artigos do carrinho de compras;
- c) Calcular recursivamente o valor total a pagar, ignorando artigos com quantidades inválidas ou negativas;
- d) Calcular recursivamente o artigo mais caro e o artigo mais barato do carrinho de compras;
- e) Apresentar um resumo dos valores acumulados por cada uma das categorias presentes no carrinho de compras.